export {default} from './EducationScreen';
