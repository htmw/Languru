export {default} from './SettingScreen';
