export {default} from './LifeScreen';
