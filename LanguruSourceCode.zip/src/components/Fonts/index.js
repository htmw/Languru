export {default} from './Fonts';
